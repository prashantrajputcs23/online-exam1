from django.db import models
# from cloudinary.models import CloudinaryField
# image = CloudinaryField('image')
from django.utils import timezone


class Course(models.Model):
    name = models.CharField(max_length=100, unique=True)
    image = models.ImageField(null=True, blank=True)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.name


class Batch(models.Model):
    name = models.CharField(max_length=100, unique=True)
    image = models.ImageField(null=True, blank=True, upload_to='batch')
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.name


class Student(models.Model):
    roll_no = models.CharField(max_length=10, unique=True, blank=True, null=True)
    batch = models.ForeignKey(Batch, on_delete=models.CASCADE, related_name='students')
    course = models.ForeignKey(Course, on_delete=models.CASCADE, related_name='students')
    name = models.CharField(max_length=100)
    father_name = models.CharField(max_length=100)
    gender = models.CharField(
        max_length=11,
        choices=(
            ('MALE', 'MALE'),
            ('FEMALE', 'FEMALE'),
            ('TRANSGENDER', 'TRANSGENDER'),
        ),
        default='MALE',
    )
    password = models.CharField(max_length=6, null=True, blank=True, default='1111')
    is_active = models.BooleanField(default=True)
    image = models.ImageField(null=True, blank=True, upload_to='student')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.name

    def gen_roll_no(self):
        today = timezone.now()
        roll_no = f'ddu{abs(today.year%100)}{today.month}{1000+self.pk}'
        return roll_no

    def save_random_password(self):
        import random
        self.password = random.randint(1000, 9999)
        self.save()
        return self.password

    def get_random_password(self):
        import random
        return random.randint(1000, 9999)

    class Meta:
        unique_together = ['name', 'father_name', 'gender', 'batch']
        ordering = ['-created_at', 'name']