from django.db.models.signals import post_save
from django.dispatch import receiver

from student.models import Student


@receiver(post_save, sender=Student)
def create_user_profile(sender, instance, created, **kwargs):
    if created:
        instance.roll_no = instance.gen_roll_no()
        instance.save()