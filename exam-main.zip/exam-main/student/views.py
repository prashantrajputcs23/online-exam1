from django.contrib import messages
from django.contrib.auth import logout
from django.contrib.auth.decorators import login_required
from django.contrib.messages.views import SuccessMessageMixin
from django.core.exceptions import PermissionDenied
from django.db.models import Q, Avg
from django.http import JsonResponse, HttpResponse, HttpResponseForbidden
from django.shortcuts import render, redirect
from django.urls import reverse_lazy
from django.utils import timezone
from django.views.generic import ListView, CreateView, UpdateView

from exam.models import Exam
from exam.templatetags.custom_tags import is_permit
from student.forms import StudentLoginForm
from student.models import Student, Batch, Course
from student.utils import time_diff, current_student


def get_current_time():
    return timezone.now().time()


def get_today():
    return timezone.now().date()


class StudentListView(ListView):
    model = Student


class StudentCreateView(SuccessMessageMixin, CreateView):
    model = Student
    fields = '__all__'
    success_message = 'Student successfully created'
    success_url = reverse_lazy('student:student_list')


class StudentUpdateView(SuccessMessageMixin, UpdateView):
    model = Student
    fields = ['name', 'password', 'gender', 'image']
    success_message = 'successfully Updated'
    success_url = reverse_lazy('student:student_list')

    def get(self, request, *args, **kwargs):
        stud_id = kwargs.pop('pk')
        if is_permit(request.user, 'Can update student'):
            return super(StudentUpdateView, self).get(request, *args, **kwargs)

        elif current_student(self.request):
            if current_student(self.request).pk == stud_id:
                return super(StudentUpdateView, self).get(request, *args, **kwargs)
        else:
            return HttpResponseForbidden('You are not Permitted')


class BatchListView(ListView):
    model = Batch


class BatchCreateView(SuccessMessageMixin, CreateView):
    model = Batch
    fields = '__all__'
    success_message = 'Batch successfully created'
    success_url = reverse_lazy('student:batch_list')


class BatchUpdateView(SuccessMessageMixin, UpdateView):
    model = Batch
    fields = '__all__'
    success_message = 'Batch successfully Updated'
    success_url = reverse_lazy('student:batch_list')


class CourseListView(ListView):
    model = Course

    def get_queryset(self):
        query = self.request.GET.get('query')
        object_list = Course.objects.all()
        if query is not None and query != "":
            object_list = object_list.filter(name__icontains=query)
        return object_list


class CourseCreateView(SuccessMessageMixin, CreateView):
    model = Course
    fields = '__all__'
    success_message = 'Course Successfully Created'
    success_url = reverse_lazy('student:course_list')


class CourseUpdateView(SuccessMessageMixin, UpdateView):
    model = Course
    fields = '__all__'
    success_message = 'Course Successfully Updated'
    success_url = reverse_lazy('student:course_list')


def student_login(request):
    logout(request)
    form = StudentLoginForm()
    try:
        student_id = request.session['student_id']
        return redirect(reverse_lazy('student:student_dashboard'))
    except:
        if request.method == 'POST':
            roll_no = request.POST.get('roll_no')
            password = request.POST.get('password')
            student = Student.objects.filter(roll_no=roll_no)
            if student.exists():
                student = student.first()
                if password == student.password:
                    request.session['student_id'] = student.pk
                    messages.success(request, 'Authenticated.')
                    return redirect(reverse_lazy('student:student_dashboard'))
                else:
                    messages.error(request, 'Roll No or Password did not match')
            else:
                messages.error(request, 'You are not enrolled.')
    return render(request, 'student/login.html', {'form': form})


def exam_paper(request):
    context = {}
    status = False
    message = 'No exam found please confirm and login again.'
    template = 'student/exam_paper.html'
    from django.utils import timezone
    today = timezone.now().date()
    try:
        student_id = request.session['student_id']
        student = Student.objects.get(pk=student_id)
        context.update({'student': student} )
        current_time = timezone.now().time()
        print(current_time)
        today_exam = Exam.objects.filter(
            batch=student.batch,
            exam_date=today,
            is_active=True,
        ).filter(Q(start_time__hour=current_time.hour) | Q(start_time__hour=current_time.hour + 1) | Q(
            start_time__hour=current_time.hour - 1))
        if today_exam.exists():
            today_exam = today_exam.first()
            if today_exam.start_time > current_time:
                total_sec = time_diff(today_exam.start_time, current_time).seconds
                status = True
                context.update({'exam': today_exam, 'sec': total_sec})
            else:
                lat_in_min = round(time_diff(current_time, today_exam.start_time).seconds / 60, 0)
                print(lat_in_min)
                if lat_in_min > 20:
                    if student.answer.all().exists():
                        status = True
                    else:
                        status = False
                        message = "We feel sorry. You missed the exam."
                else:
                    status = True
                    message = f"Exam is started approx {lat_in_min} Min. before please Calm Down."
                    template = 'student/exam_missed.html'
        else:
            status = False
            message = 'No exam found please confirm and login again.'
            messages.error(request, f'{message}')
    except Exception as e:
        messages.error(request, f'{e}')
        return redirect(reverse_lazy('student:student_login'))
    context.update({'status': status, 'message': message})
    return render(request, template, context)


def student_dashboard(request):
    if request.user.is_authenticated:
        return redirect(reverse_lazy('exam:dashboard'))
    else:
        context = {}
        today = timezone.now().date()
        student = current_student(request)
        context.update({'student': student})
        if student:
            upcoming_exam = student.batch.exams.filter(exam_date__gte=today)
            context.update({'upcoming_exam': upcoming_exam})
            exam_count = student.batch.exams.all().count()
            context.update({'exam_count': exam_count})
            present_exam_count = student.answer.order_by('exam_id').distinct('exam_id').count()
            context.update({'present_exam_count': present_exam_count})
            results = student.results
            avg_marks = results.aggregate(average_marks=Avg('obtain_marks'))['average_marks']
            avg_marks = avg_marks if avg_marks else 0
            context.update({'avg_marks': avg_marks})
            passed_in = results.filter(is_passed=True).count()
            context.update({'passed_in': passed_in})
            last_exam_result = results.first()
            context.update({'last_exam_result': last_exam_result})
            return render(request, 'student/student_home.html', context)
        else:
            return redirect(reverse_lazy('student:student_login'))


class StudentUpExamComingListView(ListView):
    model = Exam
    template_name = 'student/student_upcoming_exam_list.html'

    def get_queryset(self):
        student = current_student(self.request)
        if student:
            return Exam.objects.filter(batch=student.batch, exam_date__gte=timezone.now().date(), is_active=True)
        else:
            return Exam.objects.none()


def get_exam_start_in(request):
    exam_id = request.GET.get('exam_id')
    data = {'status': False}
    if exam_id is not None and exam_id != '':
        exam = Exam.objects.get(pk=exam_id)
        data.update({'exam_start_in': exam.start_in_sec, 'status': True})
    return JsonResponse(data, safe=False)


def get_exam_ends_in(request):
    exam_id = request.GET.get('exam_id')
    data = {}
    data.update({'status': False})
    if exam_id is not None and exam_id != '':
        exam = Exam.objects.get(pk=exam_id)
        data.update({'exam_end_in': exam.end_in_sec, 'status': True})
    return JsonResponse(data, safe=False)


def go_to_exam(request, pk):
    exam = Exam.objects.get(pk=pk)
    student = current_student(request)
    exam_status = exam.can_take_exam(student, request)
    if exam_status['status']:
        return render(request, 'student/go_to_exam.html', {'student': student, 'exam': exam, 'exam_status': exam_status})
    else:
        return HttpResponse('You are late ..')