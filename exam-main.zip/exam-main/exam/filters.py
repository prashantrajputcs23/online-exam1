import django_filters
from exam.models import (
    Exam,
)


class ExamFilter(django_filters.FilterSet):
    class Meta:
        model = Exam
        fields = ['mode', 'batch', 'exam_date']
