from django.contrib import messages
from django.core.validators import MinValueValidator, MaxValueValidator
from django.db import models
from django.utils import timezone

from student.models import Batch, Student
from student.utils import time_diff


class Exam(models.Model):
    name = models.CharField(max_length=100, unique=True)
    mode = models.CharField(max_length=100, choices=(('ONLINE','ONLINE'),('OFFLINE','OFFLINE'),), default='ONLINE')
    batch = models.ForeignKey(Batch, on_delete=models.CASCADE, related_name='exams')
    no_of_question = models.PositiveIntegerField(default=100)
    max_marks = models.PositiveIntegerField(default=100)
    min_marks = models.PositiveIntegerField(default=33)
    is_active = models.BooleanField(default=True)
    exam_date = models.DateField()
    start_time = models.TimeField()
    end_time = models.TimeField()
    result_date = models.DateTimeField(null=True, blank=True)
    image = models.ImageField(null=True, blank=True, upload_to='exam')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.name

    class Meta:
        unique_together = ['batch', 'start_time', 'exam_date']
        ordering = ['-exam_date']

    def start_in_sec(self):
        current_time = timezone.now().time()
        return time_diff(self.start_time, current_time).seconds

    def end_in_sec(self):
        current_time = timezone.now().time()
        return time_diff(self.end_time, current_time).seconds

    def exam_late(self):
        current_time = timezone.now().time()
        return time_diff(current_time, self.start_time)

    def exam_early(self):
        current_time = timezone.now().time()
        return time_diff(self.start_time, current_time)

    def can_take_exam(self, student, request):
        early_status = False
        late_status = False
        early_by = 0
        late_by = 0

        if student.batch == self.batch:
            if self.exam_date == timezone.now().date():
                late_by = self.exam_late()
                early_by = self.exam_early()
                if early_by > late_by:
                    # print('early')
                    early_status = True
                    return {'status': True, 'early_status': early_status, 'early_by': early_by, 'late_status': late_status, 'late_by': late_by}
                else:
                    late_status = True
                    if round(late_by.seconds/60, 0) > 20:
                        if self.answersheet_set.all().exists():
                            messages.warning(request, 'Refresh page may spoil your exam !')
                            return {'status': True, 'early_status': early_status, 'early_by': early_by, 'late_status': late_status, 'late_by': late_by}
                        else:
                            messages.error(request, 'You are late in exam !')
                            return {'status': False, 'early_status': early_status, 'early_by': early_by, 'late_status': late_status, 'late_by': late_by}
                    else:
                        messages.warning(request, 'You are late less then 20 min !')
                        return {'status': True, 'early_status': early_status, 'early_by': early_by,
                                'late_status': late_status, 'late_by': late_by}

    def generate_exam_result(self):
        results = []
        students = Student.objects.filter(batch_id=self.batch_id)
        for stu in students:
            result, status = Result.objects.get_or_create(exam=self, student=stu)
            results.append(result)
            answers = stu.answer.all()
            obt = 0
            for ans in answers:
                if ans.answer.is_right_answer:
                    obt = obt+ans.answer.question.mark
            result.obtain_marks = obt
            result.save()
            if self.min_marks < result.obtain_marks:
                result.is_passed = True
                result.save()
        return results
    


class Question(models.Model):
    exam = models.ForeignKey(Exam, on_delete=models.CASCADE, related_name='questions')
    question = models.CharField(max_length=2000)
    mark = models.PositiveIntegerField(default=1, validators=[MinValueValidator(1), MaxValueValidator(5)])
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.question

    class Meta:
        ordering = ['exam__name']


class Answer(models.Model):
    question = models.ForeignKey(Question, on_delete=models.CASCADE, related_name='answers')
    answer = models.CharField(max_length=2000)
    is_right_answer = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.answer

    class Meta:
        ordering = ['?']


class AnswerSheet(models.Model):
    student = models.ForeignKey(Student, on_delete=models.CASCADE, related_name='answer')
    exam = models.ForeignKey(Exam, on_delete=models.CASCADE)
    question = models.ForeignKey(Question, on_delete=models.CASCADE)
    answer = models.ForeignKey(Answer, on_delete=models.CASCADE, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.answer.answer

    class Meta:
        unique_together = ['student', 'question']
        ordering = ['-exam']


class Result(models.Model):
    exam = models.ForeignKey(Exam, on_delete=models.CASCADE, related_name='results')
    student = models.ForeignKey(Student, on_delete=models.CASCADE, related_name='results')
    obtain_marks = models.PositiveIntegerField(null=True, blank=True)
    is_passed = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.student.name

    class Meta:
        ordering = ['-created_at']