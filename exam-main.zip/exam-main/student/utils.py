import datetime

from django.shortcuts import redirect
from django.urls import reverse_lazy

from student.models import Student


def time_diff(start, end):
    return datetime.timedelta(
        hours=start.hour,
        minutes=start.minute
    ) - datetime.timedelta(
        hours=end.hour, minutes=end.minute)


def current_student(request):
    try:
        student_id = request.session['student_id']
        return Student.objects.get(pk=student_id)
    except:
        return Student.objects.none()