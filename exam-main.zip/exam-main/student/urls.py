from django.contrib.auth.decorators import login_required
from django.urls import path

from student.views import (
    StudentListView,
    StudentCreateView,
    BatchListView,
    CourseCreateView,
    BatchCreateView,
    CourseListView,
    student_login,
    exam_paper,
    student_dashboard,
    StudentUpdateView, BatchUpdateView, CourseUpdateView, StudentUpExamComingListView, get_exam_start_in,
    get_exam_ends_in,
    go_to_exam
)

app_name= 'student'
urlpatterns = [
    path('', login_required(StudentListView.as_view()), name='student_list'),
    path('create', login_required(StudentCreateView.as_view()), name='student_create'),
    path('edit/<int:pk>', StudentUpdateView.as_view(), name='student_edit'),
    path("batch/create", login_required(BatchCreateView.as_view()), name='create_batch'),
    path("batch/edit/<int:pk>", login_required(BatchUpdateView.as_view()), name='edit_batch'),
    path('batch/all', login_required(BatchListView.as_view()), name='batch_list'),
    path("course/create", login_required(CourseCreateView.as_view()), name='create_course'),
    path("course/edit/<int:pk>", login_required(CourseUpdateView.as_view()), name='edit_course'),
    path("course/all", login_required(CourseListView.as_view()), name='course_list'),
    path('login', student_login, name='student_login'),
    path('exam_paper', exam_paper, name='exam_paper'),
    path('home', student_dashboard, name='student_dashboard'),
    path('upcoming_exam', StudentUpExamComingListView.as_view(), name='upcoming_exam'),
    path('exam_end_in', get_exam_ends_in, name='exam_end_in'),
    path('exam_start_in', get_exam_start_in, name='exam_start_in'),
    path('got_exam/<int:pk>', go_to_exam, name='go_to_exam'),
]