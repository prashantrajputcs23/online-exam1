from student.models import Student


def current_student(request):
    try:
        student_id = request.session['student_id']
        return {'current_student': Student.objects.get(pk=student_id)}
    except:
        return {'current_student': None}