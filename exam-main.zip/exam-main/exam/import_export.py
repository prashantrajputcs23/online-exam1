import datetime
import pandas as pd
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.http import HttpResponse

try:
    from io import BytesIO as IO
except ImportError:
    from io import StringIO as IO


@login_required(login_url='login')
def export_to_xlsx(request, data_frame, name):

    data_frame['created_at'] = data_frame['created_at'].dt.tz_localize(None)
    data_frame['updated_at'] = data_frame['created_at'].dt.tz_localize(None)
    excel_file = IO()
    xlwriter = pd.ExcelWriter(excel_file, engine='xlsxwriter')
    data_frame.to_excel(xlwriter, name)
    xlwriter.save()
    xlwriter.close()
    excel_file.seek(0)
    response = HttpResponse(
        excel_file.read(),
        content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    )
    file_name = f"{name}_at_{datetime.datetime.now()}.xlsx"
    response['Content-Disposition'] = f'attachment; filename="{file_name}"'
    messages.add_message(request, messages.SUCCESS, 'Successfully exported.')
    return response
