import pandas as pd
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.contrib.messages.views import SuccessMessageMixin
from django.http import JsonResponse
from django.shortcuts import render
from django.urls import reverse_lazy
from django.views.generic import TemplateView, CreateView, ListView, UpdateView

from exam.import_export import export_to_xlsx
from exam.models import Question, Answer, Exam, AnswerSheet
from exam.templatetags.custom_tags import is_permit, has_permission_list
from student.models import Student, Batch, Course


class Dashboard(TemplateView):
    def get_context_data(self, **kwargs):
        context = {'student_count': Student.objects.all().count()}
        return context
    template_name = 'index.html'


@login_required(login_url='login')
def import_student(request):
    context = {'form_name': 'Upload Student Sheet (.xls)', 'link': '/static/sample_format/student.xls'}
    if request.method == 'POST':
        permission_list = ['can add student', 'can add batch', 'can add course']
        if has_permission_list(request.user, permission_list):
            file = request.FILES.get('file')
            if file:
                df = pd.read_excel(file)
                batches = df.Batch.unique()
                for batch in batches:
                    temp = Batch.objects.get_or_create(name=batch)

                courses = df.Course.unique()
                for course in courses:
                    temp = Course.objects.get_or_create(name=course)

                temp = []
                for index, row in df.iterrows():
                    batch = Batch.objects.get(name=row['Batch'])
                    course = Course.objects.get(name=row['Course'])
                    temp.append(
                        Student(
                            batch=batch,
                            course=course,
                            name=row['Name'],
                            father_name=row['Father'],
                            gender=row['Gender']
                        )
                    )
                data = Student.objects.bulk_create(temp)
                roll_no = []
                password = []
                created_at = []
                updated_at = []
                for student in data:
                    student.roll_no = student.gen_roll_no()
                    student.password = student.get_random_password()
                    student.save()
                    roll_no.append(student.roll_no)
                    password.append(student.password)
                    created_at.append(student.created_at)
                    updated_at.append(student.updated_at)
                df.insert(0, 'Roll No', roll_no)
                df.insert(1, 'Password', password)
                df.insert(7, 'created_at', created_at)
                df.insert(8, 'updated_at', updated_at)
                context.update({'table': df.to_html()})
                return export_to_xlsx(
                    request,
                    df,
                    'students'
                )
            else:
                messages.error(request, f'Please choose file ! ')
                return render(request, 'exam/import.html', context)
        else:
            messages.error(request, f'You Dont have required permission {permission_list} ! ')
            return render(request, 'exam/import.html', context)
    if request.GET.get('next') == '/':
        return render(request, 'index.html', context)
    return render(request, 'exam/import.html', context)


@login_required(login_url='login')
def import_exam(request):
    context = {'form_name': 'Upload Exam Sheet (.xls)', 'link': '/static/sample_format/exam.xls'}
    if request.method == 'POST':
        if is_permit(request.user, 'can add exam'):
            file = request.FILES.get('file')
            if file:
                df = pd.read_excel(file)
                temp = []
                for index, row in df.iterrows():
                    batch = Batch.objects.get(name=row['batch'])
                    temp.append(
                        Exam(
                            name=row['name'],
                            mode =row['mode'],
                            batch=batch,
                            no_of_question=row['no_of_question'],
                            max_marks=row['max_marks'],
                            min_marks=row['min_marks'],
                            exam_date=row['exam_date'],
                            start_time=row['start_time'],
                            end_time=row['end_time'],
                        )
                    )
                Exam.objects.bulk_create(temp)
                context.update({'table': df.to_html()})
            else:
                messages.error(request, f'Please choose file')
                return render(request, 'exam/import.html', context)
        else:
            messages.error(request, f'You Dont have required permission "can add exam" ! ')
            return render(request, 'exam/import.html', context)
    if request.GET.get('next') == '/':
        return render(request, 'index.html', context)
    return render(request, 'exam/import.html', context)


@login_required(login_url='login')
def import_question(request):
    context = {'form_name': 'Question Student Sheet (.xls)', 'link': '/static/sample_format/question.xls'}
    if request.method == 'POST':
        permission_list = ['can add question', 'can add answer']
        if has_permission_list(request.user, permission_list):
            file = request.FILES.get('file')
            if file:
                df = pd.read_excel(file)
                for index, row in df.iterrows():
                    exam = Exam.objects.get(name=row['exam_name'])
                    ques = Question.objects.create(
                        question=row['question'],
                        exam=exam,
                    )
                    answers = [row['answer1'], row['answer2'], row['answer3'], row['answer4']]
                    right_answer = row['right_answer']
                    for ans in answers:
                        is_right = False
                        if ans == right_answer:
                            is_right = True
                        Answer.objects.create(question=ques, answer=ans, is_right_answer=is_right)

                context.update({'table': df.to_html()})
            else:
                messages.error(request, f'Please choose the file ')
                return render(request, 'exam/import.html', context)
        else:
            messages.error(request, f'You Dont have required permission {permission_list} ! ')
            return render(request, 'exam/import.html', context)
    if request.GET.get('next') == '/':
        return render(request, 'index.html', context)
    return render(request, 'exam/import.html', context)


class ExamCreateView(SuccessMessageMixin, CreateView):
    model = Exam
    fields = '__all__'
    success_url = reverse_lazy('exam:exam_list')
    success_message = 'Exam Successfully Created'


class ExamUpdateView(SuccessMessageMixin, UpdateView):
    model = Exam
    fields = '__all__'
    success_url = reverse_lazy('exam:exam_list')
    success_message = 'Exam Successfully Created'


class GridTemplate(TemplateView):
    template_name = 'exam/grid.html'


class ExamListView(ListView):
    model = Exam


class QuestionListView(ListView):
    model = Question
    paginate_by = 100


def load_question(request):
    exam_id = request.GET.get('exam_id')
    student_id = request.GET.get('student_id')
    print(student_id)
    print(exam_id)
    answer_sheet_questions = AnswerSheet.objects.filter(exam_id=exam_id, student_id=student_id).values_list('question_id', flat=True)
    print(answer_sheet_questions)
    question = Question.objects.exclude(id__in=answer_sheet_questions).filter(exam_id = exam_id).order_by('?').last()
    print(question)
    return render(request, 'exam/question_single.html', {'question': question})


def submit_answer(request):
    student_id = request.GET.get('student_id')
    exam_id = request.GET.get('exam_id')
    question_id = request.GET.get('question_id')
    answer_id = request.GET.get('answer_id')
    try:
        sheet, s = AnswerSheet.objects.get_or_create(student_id=student_id, exam_id=exam_id, question_id=question_id)
        sheet.answer_id=answer_id
        sheet.save()
        status = True
        message = 'answer successfully saved'
    except Exception as e:
        status = False
        message = e
    return JsonResponse({'status': True, 'message': message})


@login_required(login_url='login')
def export_student(request):
    student_query_object = Student.objects.all()
    data_frame = pd.DataFrame(list(student_query_object.values(
            'id',
            'roll_no',
            'password',
            'name',
            'father_name',
            'gender',
            'course__name',
            'batch__name',
            'is_active',
            'created_at',
            'updated_at',
        )))
    return export_to_xlsx(
        request,
        data_frame,
        'students'
    )


def gen_result(request, exam_id):
    if is_permit(request.user, 'can add result'):
        exam = Exam.objects.get(pk=exam_id)
        results = exam.generate_exam_result()
        return render(request, 'exam/result_list.html', {'results': results})
    else:
        messages.error(request, 'You do not have permission !')
        return render(request, 'exam/result_list.html')