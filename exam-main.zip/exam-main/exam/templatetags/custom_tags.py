from django import template

from student.models import Student

register = template.Library()


@register.filter(name='has_group')
def has_group(user, group_name):
    return user.groups.filter(name=group_name).exists()


@register.filter(name='is_permit')
def is_permit(user, permission):
    groups = user.groups.all()
    if groups:
        try:
            for group in groups:
                if group.permissions.filter(name__icontains=permission).count() > 0:
                    return True
        except:
            return False
    else:
        return False


@register.filter(name='has_permission_list')
def has_permission_list(user, permission):
    groups = user.groups.all()
    false_count = 0
    if groups:
        try:
            for group in groups:
                for param in permission:
                    if not group.permissions.filter(name__icontains=param).count() > 0:
                        false_count += 1
            if false_count > 0:
                return False
            else:
                return True
        except:
            return False
    else:
        return False


# @register.simple_tag(takes_context=True)
@register.filter(name='url_with_param')
def url_with_param(request):
    url = ""
    for key, value in request.GET.items():
        if key != 'page':
            url += f'&{key}={value}'
    return url


@register.filter(name='current_student')
def current_student(request):
    try:
        student_id = request.session['student_id']
        return Student.objects.get(pk=student_id)
    except:
        return Student.objects.none()


@register.filter(name='current_student_id')
def current_student_id(request):
    try:
        student_id = request.session['student_id']
        return Student.objects.get(pk=student_id).pk
    except:
        return Student.objects.none()