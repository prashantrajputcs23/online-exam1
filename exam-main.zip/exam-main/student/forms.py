from django import forms

from student.models import Student


class StudentLoginForm(forms.ModelForm):
    password = forms.CharField(widget=forms.PasswordInput())

    class Meta:
        model = Student
        fields = ['roll_no', 'password']

    def login(self):
        pass