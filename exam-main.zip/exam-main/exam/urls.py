from django.contrib.auth.decorators import login_required
from django.urls import path
from . import views

app_name = 'exam'

urlpatterns = [
    path("", login_required(views.Dashboard.as_view()), name='dashboard'),
    path("grid/", login_required(views.GridTemplate.as_view()), name='grid'),
    path("exam/create", login_required(views.ExamCreateView.as_view()), name='create_exam'),
    path("exam/edit/<int:pk>", login_required(views.ExamUpdateView.as_view()), name='create_exam'),
    path("exam/all", login_required(views.ExamListView.as_view()), name='exam_list'),
    path("exam/question/all", login_required(views.QuestionListView.as_view()), name='question_list'),
    path("import/student", views.import_student, name='import_student'),
    path("import/exam", views.import_exam, name='import_exam'),
    path("import/question", views.import_question, name='import_question'),
    path("load_question", views.load_question, name='load_question'),
    path("submit_answer", views.submit_answer, name='submit_answer'),
    path("gen_result/<int:exam_id>", views.gen_result, name='gen_result'),
]